package com.app.kholoud.foodshare;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class register extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        final EditText charityName = (EditText) findViewById(R.id.charityName);
        final EditText charityAddress = (EditText) findViewById(R.id.charityAddress);
        final EditText charityMobile = (EditText) findViewById(R.id.charityMobile);
        final EditText charityEmail = (EditText) findViewById(R.id.charityEmail);
        final EditText charityPassword = (EditText) findViewById(R.id.charityPassword);
        final EditText charityActivity = (EditText) findViewById(R.id.charityActivaty);
        final EditText charityAvailability = (EditText) findViewById(R.id.charityAvailability);

        final Button charityRegister = (Button) findViewById(R.id.charityRegister);
        final Button buttonback = (Button) findViewById(R.id.buttonback);

        final TextView textView2Contact = (TextView) findViewById(R.id.textView2);
        final TextView textView3Additional = (TextView) findViewById(R.id.textView3);
        final TextView textViewAlready = (TextView) findViewById(R.id.textView);

        // Button to Homepage
        buttonback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent homePage = new Intent(register.this, MainActivity.class);
                register.this.startActivity(homePage) ;
            }
        });


    }
}
